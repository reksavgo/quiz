# littlebit.zip: versi tanpa database

Kuis 15 pertanyaan random, absurd, dan sedikit PDKT. Setelah setiap pilihan, muncul respons khusus. Di akhir, ada hasil kocak untuk hiburan.

## Cara pakai
1. Ekstrak ZIP.
2. Buka `index.html` di browser, atau upload folder ini ke hosting statis seperti GitHub Pages/Netlify.
3. Tidak perlu membuat akun Supabase, mengisi token, atau menyiapkan database.

## Privasi
Semua jawaban diproses di browser dan tidak disimpan atau dikirim ke server. Font eksternal dimuat dari Google Fonts jika internet tersedia.

## Isi proyek
- `index.html`: tampilan halaman
- `styles.css`: desain responsif
- `questions.js`: 15 pertanyaan, pilihan, dan respons
- `app.js`: navigasi kuis dan hasil akhir
