window.QUIZ_QUESTIONS = [
  {
    "q": "lu bangun tidur, eh malah jadi barang. lu milih jadi apaan jir?",
    "a": [
      "sendok biar tau gosip keluarga 🥄",
      "bantal, cita-cita gw jadi DJ",
      "charger biar dicariin mulu 🔌",
      "galon yang punya masa lalu kelam"
    ],
    "r": [
      "sendok doang tapi tau semua aib keluarga. bahaya juga lu.",
      "tiap malem nge-DJ: duk duk duk, tetangga auto pindah.",
      "akhirnya ada yang ngerti penderitaan charger ilang-ilangan.",
      "galonnya diem aja, tapi masa lalunya lebih berat dari isi airnya."
    ],
    "type": "random"
  },
  {
    "q": "misal alien tiba-tiba nongol depan rumah terus nanya 'bumi punya siapa?', lu jawab apa?",
    "a": [
      "yang punya wifi, bang 📶",
      "tergantung, bawa oleh-oleh nggak? 👽",
      "bumi lagi maintenance, balik besok",
      "punya kucing, kita cuma numpang 🐈"
    ],
    "r": [
      "diplomasi antarplanet dimulai dari nanya password wifi. valid.",
      "alien baru nyampe aja udah kena syarat dan ketentuan.",
      "bumi lagi error bang, coba refresh dulu.",
      "kucing lu denger ini terus langsung naikin uang sewa."
    ],
    "type": "random"
  },
  {
    "q": "kalo hidup lu ada tombol skip, lu mau skip bagian yang mana?",
    "a": [
      "nunggu orang siap-siap padahal katanya bentar",
      "iklan yang ga bisa diskip",
      "otak muter ulang chat jadul jam 2 pagi",
      "tutorial hidup yang ga ada tombol close"
    ],
    "r": [
      "kata 'bentar' tuh satuan waktunya emang ga jelas.",
      "iklan 30 detik aja bisa berasa satu semester.",
      "otak lu bioskop 24 jam, sayangnya ga bisa pilih film.",
      "mana tombol X-nya jir, gw mau keluar dari tutorial."
    ],
    "type": "random"
  },
  {
    "q": "ada yang ngechat 'kita perlu ngobrol', otak lu langsung ngapain?",
    "a": [
      "bikin 38 teori sendiri",
      "bales santai 'emang kenapa?'",
      "pengen berubah jadi batu",
      "nyari cemilan dulu biar siap mental"
    ],
    "r": [
      "baru satu kalimat, otak lu udah bikin rapat darurat.",
      "santai banget lu, ajarin dong biar ga overthinking.",
      "batu aja ga punya masalah beginian, enak juga.",
      "minimal kalo obrolannya berat, keripik tetap menemani."
    ],
    "type": "personality"
  },
  {
    "q": "lu harus kabur dari naga yang nagih utang. naik apa jir?",
    "a": [
      "sepeda, klaksonnya suara bebek 🚲",
      "karpet terbang tapi harus dicas",
      "lari sambil bilang 'permisi bang naga'",
      "kura-kura yang punya SIM"
    ],
    "r": [
      "kwek kwek buat ngelawan naga? strategi lu di luar nalar.",
      "baru terbang bentar udah lowbat. teknologi ampas.",
      "dikejar naga aja masih sopan, calon menantu idaman RT.",
      "kura-kuranya driver senior, rating 4,9 bintang."
    ],
    "type": "random"
  },
  {
    "q": "kalo ada orang inget hal kecil tentang lu, reaksi lu gimana?",
    "a": [
      "b aja sih, tapi gw inget terus",
      "curiga dia intel",
      "senyum dikit terus sok cool",
      "langsung gw anggap warga kehormatan"
    ],
    "r": [
      "mukanya b aja, dalem hati udah disimpen di folder favorit.",
      "jangan-jangan dia tau password wifi lu juga.",
      "lu sok cool, padahal dalem hati udah salto.",
      "kartu anggota lagi dicetak, berlaku sampe kiamat."
    ],
    "type": "romance"
  },
  {
    "q": "menurut lu awan di langit bentuknya kayak apaan?",
    "a": [
      "nasi goreng gagal diaduk 🍳",
      "anjing yang inget cicilan",
      "peta ke warung rahasia",
      "dinosaurus yang udah pensiun"
    ],
    "r": [
      "langit hari ini jual nasi goreng rasa angin.",
      "ternyata awan juga punya tanggungan hidup.",
      "ikuti awannya, siapa tau beneran nemu warung enak.",
      "kasian dinosaurus, biarin dia menikmati masa tua."
    ],
    "type": "random"
  },
  {
    "q": "kalo chat lu dibales 'wkwk', menurut lu artinya apa?",
    "a": [
      "dia beneran ketawa",
      "kode rahasia perkumpulan tertentu",
      "tanda baca hubungan manusia",
      "keyboard dia masih berfungsi"
    ],
    "r": [
      "semoga ketawa beneran, bukan cuma formalitas negara.",
      "coba hubungi badan teori konspirasi sekarang juga.",
      "bahasa manusia emang ribet, tiga huruf aja bisa dianalisis.",
      "setidaknya keyboard-nya masih punya tujuan hidup."
    ],
    "type": "personality"
  },
  {
    "q": "pilih satu makhluk buat tinggal bareng lu. pilih yang paling ga normal.",
    "a": [
      "hantu tapi rajin nyapu",
      "ayam yang suka ngasih wejangan 🐓",
      "robot vacuum yang nge-judge lu",
      "ikan cupang namanya Pak RT"
    ],
    "r": [
      "rumah bersih sih, cuma tiap malem suhu ruangan turun sendiri.",
      "nasihatnya suruh bangun pagi, terus dia berisik jam 3.",
      "debu ilang, harga diri lu juga ikut dibersihin.",
      "Pak RT mantau dari akuarium. jangan lupa iuran pelet."
    ],
    "type": "random"
  },
  {
    "q": "pas lu lagi capek, perhatian kayak apa yang paling lu butuhin?",
    "a": [
      "ditemenin aja, ga usah banyak ngomong",
      "dikirimin meme receh",
      "ditawarin makan tanpa banyak tanya",
      "dikasih waktu sendiri dulu"
    ],
    "r": [
      "bisa diem bareng tanpa harus jadi host podcast.",
      "memennya jelek, tapi timing-nya pas. susah dilawan.",
      "kadang 'nih makan dulu' udah lebih dari cukup.",
      "pengen sendiri bentar bukan berarti mau pindah planet."
    ],
    "type": "personality"
  },
  {
    "q": "kalo lu bisa bikin satu aturan baru buat seluruh dunia, apa?",
    "a": [
      "charger wajib punya kaki",
      "hari Senin cuma boleh muncul dua kali setahun",
      "yang bilang otw harus udah pake sepatu",
      "cilok gratis tiap tanggal tua"
    ],
    "r": [
      "biar charger ga kabur ke dimensi lain lagi.",
      "akhirnya ada kebijakan yang bener-bener dibutuhin rakyat.",
      "aturan ini bisa mengurangi kebohongan nasional secara drastis.",
      "ekonomi dunia diselamatkan sama cilok dan bumbu kacang."
    ],
    "type": "random"
  },
  {
    "q": "kalo udah nyaman sama seseorang, biasanya lu jadi gimana?",
    "a": [
      "cerita hal receh yang ga penting",
      "ngirim meme tanpa konteks",
      "pelan-pelan jadi diri sendiri",
      "inget hal kecil yang dia suka"
    ],
    "r": [
      "cerita tutup botol ilang aja udah tanda percaya tingkat tinggi.",
      "kalo dia paham meme lu, mungkin frekuensi otak kalian sama.",
      "ga harus jaim terus. capek juga jadi orang lain.",
      "hal kecil kadang malah nyangkut paling lama di kepala."
    ],
    "type": "romance"
  },
  {
    "q": "lu dikasih satu tombol ajaib. efeknya rada ga ngotak.",
    "a": [
      "nyamuk jadi sopan",
      "tiap jatuh ada efek suara kartun",
      "bisa tau siapa yang nyomot kentang goreng",
      "kalo bilang 'bentar' waktu langsung berhenti"
    ],
    "r": [
      "nyamuknya ngetuk pintu dulu: permisi, saya mau ganggu.",
      "jatuh dikit bunyi boing. malu mah urusan belakangan.",
      "akhirnya kasus kentang goreng masuk tahap penyidikan.",
      "semua orang bakal bilang bentar terus dunia berhenti selamanya."
    ],
    "type": "random"
  },
  {
    "q": "kalo orang yang lu suka tiba-tiba ngajak jalan, lu ngapain duluan?",
    "a": [
      "gas aja, outfit dipikir sambil jalan",
      "nanya tempatnya dulu, takut diajak ke Mars",
      "senyum sendiri baru bales",
      "cek saldo sambil berdoa"
    ],
    "r": [
      "gas dulu, panik outfit belakangan.",
      "wajar, siapa tau tujuan akhirnya imigrasi Mars.",
      "chat baru masuk, senyum lu udah ga bisa diajak kerja sama.",
      "romantis boleh, tapi ongkos pulang jangan dilupain."
    ],
    "type": "romance"
  },
  {
    "q": "pertanyaan terakhir, kalo bebek natap lu 8 detik, menurut lu kenapa?",
    "a": [
      "dia tau dosa-dosa gw",
      "dia mau ngajak bisnis",
      "ya bebek doang, ngapain dipikirin",
      "gw tatap balik, harga diri taruhannya"
    ],
    "r": [
      "bebek itu megang bukti. jangan pernah remehin paruh.",
      "kontraknya dikirim lewat kolam, tanda tangan pake kaki.",
      "akhirnya ada yang jawab normal di kuis absurd ini.",
      "adu tatap dimulai. yang kedip duluan traktir es teh."
    ],
    "type": "random"
  }
];
