function boot() {
  const questions = window.QUIZ_QUESTIONS || [];
  let index = 0;
  let answers = Array(questions.length).fill(null);
  const $ = (id) => document.getElementById(id);
  const screens = {intro:$('intro'),quiz:$('quiz'),done:$('done')};
  function screen(name) { Object.values(screens).forEach(s => s.classList.add('hidden')); screens[name].classList.remove('hidden'); window.scrollTo({top:0,behavior:'smooth'}); }
  function render() {
    const q = questions[index];
    $('question-label').textContent = `SOAL ${String(index+1).padStart(2,'0')}`;
    $('progress-label').textContent = `${index+1} / ${questions.length}`;
    $('progress-fill').style.width = `${((index+1)/questions.length)*100}%`;
    $('question-title').textContent = q.q;
    $('question-mark').textContent = ['✳','☼','✦','♡','🛸','🦆'][index%6];
    $('options').replaceChildren();
    q.a.forEach((answer, i) => {
      const btn = document.createElement('button');
      btn.className = 'option' + (answers[index] === i ? ' selected' : '');
      const letter = document.createElement('span'); letter.className = 'letter'; letter.textContent = String.fromCharCode(65+i);
      const label = document.createElement('span'); label.textContent = answer;
      btn.append(letter,label);
      btn.addEventListener('click', () => { answers[index] = i; render(); });
      $('options').append(btn);
    });
    const reaction = $('reaction');
    reaction.classList.toggle('hidden', answers[index] === null);
    reaction.replaceChildren();
    if (answers[index] !== null) {
      const heading = document.createElement('span'); heading.className = 'reaction-label'; heading.textContent = 'KATA LITTLEBIT' ;
      const message = document.createElement('p'); message.className = 'reaction-message'; message.textContent = q.r[answers[index]];
      reaction.append(heading,message);
    }
    $('back-btn').disabled = index === 0;
    $('next-btn').disabled = answers[index] === null;
    $('next-btn').textContent = index === questions.length-1 ? 'liat hasilnya jir ✨' : 'lanjut aja →';
  }
  function showResult() {
    const sum = answers.reduce((total, choice, i) => total + (choice+1)*(i+3), 0);
    const results = [
      ['MAKHLUK RANDOM BERSERTIFIKAT','Otak lu kayak browser kebanyakan tab. Ada yang muter lagu, ada yang error, satu lagi entah kebuka kapan. tapi yaudah, lanjutkan hidup jir.'],
      ['TOKOH UTAMA SITKOM','Hidup lu belum ada script-nya, tapi omongan spontan lu bisa bikin orang ngakak. asal jangan debat sama naga aja.'],
      ['PENJAGA RAHASIA KECIL','Lu keliatannya santai, tapi hal kecil bisa lu inget lama banget. tenang, ga bakal gw spill ke publik kok.'],
      ['MANUSIA PAKE DLC','Lu ada sisi random, sisi perhatian, sama sisi pengen rebahan seharian. paket lengkap, update berikutnya belum diketahui.'],
      ['DUTA BESAR BUMI','Kalo alien dateng, kayaknya lu yang disuruh ngomong duluan. semoga mereka mau dibayar pake cilok.'],
      ['ANAK TEORI KENTANG','Lu bisa mikirin hal receh sampe jadi teori nasional. ga ada manfaatnya sih, tapi lumayan buat hiburan wkwk.']
    ];
    const result = results[sum % results.length];
    $('result-title').textContent = result[0];
    $('result-copy').textContent = result[1];
    screen('done');
  }
  $('start-btn').addEventListener('click', () => { screen('quiz'); render(); });
  $('back-btn').addEventListener('click', () => { if(index>0){index--;render();} });
  $('next-btn').addEventListener('click', () => {
    if (answers[index] === null) return;
    if (index < questions.length-1) { index++; render(); return; }
    showResult();
  });
  $('restart-btn').addEventListener('click', () => { index=0; answers=Array(questions.length).fill(null); screen('intro'); });
}
boot();
